import React,{useState} from 'react';
import '../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import Sidebar from './Sidebar';
import Navbar from './Navbar';
import { useNavigate } from 'react-router-dom';
import axios from "axios";

// const initialState = {
//     DistributorName:"",
//     ContactPerson:"",
//     ContactEmail:"",
//     ContactNumber:"",
//     AddressLine1:"",
//     AddressLine2:"",
//     DistributorGSTN:"",
//     City:"",
//     State:"",
//     Country:"",
//     Pincode:"",
//     Status:""

// }

const AddDistributors = () => {
    // const[id,idchange]=useState("");
    // const[DistributorName,namechange]=useState("");
    // const[ContactPerson,ContactPersonchange]=useState("");
    // const[ContactEmail,ContactEmailchange]=useState("");
    // const[ContactNumber,ContactNumberchange]=useState("");
    // const[AddressLine1,AddressLine1change]=useState("");
    // const[AddressLine2,AddressLine2change]=useState("");
    // const[DistributorGSTN,DistributorGSTNchange]=useState("");
    // const[City,Citychange]=useState("");
    // const[State,Statechange]=useState("");
    // const[Country,Countrychange]=useState("");
    // const[Pincode,Pincodechange]=useState("");
    // const[Status,Statuschange]=useState("");
    // // const[image,Imagechange]=useState("");
    // const[validation,valchange]=useState(false);


    // const navigate=useNavigate();

    // const handleSubmit=(e)=>{
    //   e.preventDefault();
    //   const empdata={DistributorName,ContactPerson,ContactEmail,ContactNumber,AddressLine1,AddressLine2,DistributorGSTN,City,State,Country,Pincode,Status};
      

    //   fetch("http://localhost:8000/employee",{
    //     method:"POST",
    //     headers:{"content-type":"application/json"},
    //     body:JSON.stringify(empdata)
    //   }).then((res)=>{
    //     console.log(res);
    //     alert('Saved successfully.')
    //     navigate('/');
    //   }).catch((err)=>{
    //     console.log(err.message)
    //   })

    // }

//     const history = useNavigate();
//     const [state,setState]=useState(initialState);

//     const {DistributorName,ContactPerson,ContactEmail,ContactNumber,AddressLine1,AddressLine2,DistributorGSTN,City,State,Country,Pincode,Status}= initialState;

//     const addContact = async(data) =>{
//         const res = await axios.post("http://localhost:5000/create", data)
//         if(res.status === 200){
//             alert("successfull added")
//         }
//     }
 
//  const handleSubmit = (e) =>{
//     e.preventDefault();
//     if(!DistributorName || !ContactPerson || !ContactEmail || !ContactNumber ||!AddressLine1 || !AddressLine2 || !DistributorGSTN || !City ||  !State || !Country || !Pincode  || !Status){
//             console.log("please fill details")
//         }else{
//             addContact(state);
//             history.push("/");
//         }
//  }

//     const setdata=(e)=>{
        
//         // const {DistributorName,ContactPerson,ContactEmail,ContactNumber,AddressLine1,AddressLine2,DistributorGSTN,City,State,Country,Pincode,Status}= initialState;
//         console.log(e.target.value);
//         const {name,value} = e.target;
//         setState({state, [name]:value });
            

//         };
    
   
    // const setdata = async (data)=>{
    //     data.preventDefault();
        
        // const {DistributorName,ContactPerson,ContactEmail,ContactNumber,AddressLine1,AddressLine2,DistributorGSTN,City,State,Country,Pincode,Status}= initialState;

        // if(!DistributorName || ContactPerson || ContactEmail || ContactNumber ||AddressLine1 || AddressLine2 || DistributorGSTN || City ||  State || Country || Pincode  || Status){
        //     console.log("please fill details")
        // }
        // const res = await axios.post("http://localhost:5000/create", data)
        // if(res.status === 200){
        //     alert("successfull added")
        // }
           
        let history = useNavigate();
        const [user, setUser] = useState({
          DistributorName:"",
              ContactPerson:"",
              ContactEmail:"",
              ContactNumber:"",
              AddressLine1:"",
              AddressLine2:"",
              DistributorGSTN:"",
              City:"",
              State:"",
              Country:"",
              Pincode:"",
              Status:""
         
        });
      
        const { DistributorName,ContactPerson,ContactEmail,ContactNumber,AddressLine1,AddressLine2,DistributorGSTN,City,State,Country,Pincode,Status } = user;
       
        const onInputChange = e => {
          setUser({ ...user, [e.target.name]: e.target.value });
        };
      
        const onSubmit = async e => {
          e.preventDefault();
          await axios.post("http://localhost:3003/users", user);
          history("/");
        };
           
        
    
  return (
   
       
    
    <div className='row bg-light'>
        
        <div className='col-md-3'>
    <Sidebar/>
        </div>
    <div className='col-md-9'>
    <div className='row bg-white'>
            <Navbar/>
            </div>
    <pre className='mt-2'>ManageDistributors &gt; Add Distributors</pre>
    <div class="card">
      <div className="card-body">
       <form className="mt-1" onSubmit={onSubmit}>
                <div className="row">
                     <div className=" col-md-9 col-lg-9 col-12">
                    <div className='row'>
                    <div className=" mb-3 col-lg-6 col-md-6 col-12">
                        <label htmlFor="DistributorName" className="form-label">DistributorName</label>
                        <input
              type="text"
              className="form-control form-control-sm"
              placeholder="DISTRIBUTOR NAME"
              name="DistributorName"
              value={DistributorName}
              onChange={e => onInputChange(e)}
            />
          </div>
                    {/* </div> */}
                    
                    <div className=" col-lg-6 col-md-6 col-12">
                        <label htmlFor="exampleInputPassword1" className="form-label">ContactPerson</label>
                        <input
              type="text"
              className="form-control form-control-sm"
              placeholder="CONTACT PERSON"
              name="ContactPerson"
              value={ContactPerson}
              onChange={e => onInputChange(e)}
            />
          </div>
                    </div>
                    
                    <div className='row'>
                    <div className="mb-3 col-lg-6 col-md-6 col-12">
                        <label htmlFor="ContactEmail" className="form-label">ContactEmail</label>
                        <input
              type="text"
              className="form-control form-control-sm"
              placeholder="CONTACT EMAIL"
              name="ContactEmail"
              value={ContactEmail}
              onChange={e => onInputChange(e)}
            />
                    </div>
                    <div class="mb-3 col-lg-6 col-md-6 col-12">
                        <label htmlFor="ContactNumber" className="form-label">ContactNumber</label>
                       
                        <input
              type="text"
              className="form-control form-control-sm"
              placeholder="CONTACT NUMBER"
              name="ContactNumber"
              value={ContactNumber}
              onChange={e => onInputChange(e)}
            />
                    </div>
                    </div>
                    <div className='row'>
                    <div className="col-lg-6 col-md-6 col-12">
                        <label htmlFor="AddressLine1" className="form-label">AddressLine1</label>
                        
                        <input
              type="text"
              className="form-control form-control-sm"
              placeholder="ADDRESSLINE1"
              name="AddressLine1"
              value={AddressLine1}
              onChange={e => onInputChange(e)}
            />
                    </div>
                    <div className="col-lg-6 col-md-6 col-12">
                        <label htmlFor="AddressLine2" className="form-label">AddressLine2</label>
                    
                        <input
              type="text"
              className="form-control form-control-sm"
              placeholder="ADDRESSLINE2"
              name="AddressLine2"
              value={AddressLine2}
              onChange={e => onInputChange(e)}
            />
                    </div>
                    </div>
                    </div>
                    </div>

                    <div className="col-md-3 col-lg-3 col-12">
                        <div className='form-outline mt-4'>
                       
                    </div>
                  
                 
                   </div>
                   
                     <div className='p-0'>
                    <div className='row mt-0'>
                    <div className="mb-3 col-lg-6 col-md-6 col-12">
                        <label htmlFor="DistributorGSTN" className="form-label">DistributorGSTN</label>
                        
                        <input
              type="text"
              className="form-control  form-control-sm"
              placeholder="DISTRIBUTOR GSTN"
              name="DistributorGSTN"
              value={DistributorGSTN}
              onChange={e => onInputChange(e)}
            />
                      

                    </div>
                    <div className="mb-3 col-lg-6 col-md-6 col-12">
                        <label htmlFor="City" className="form-label">CITY</label>
                      
                        <input
              type="text"
              className="form-control form-control-sm"
              placeholder="CITY"
              name="City"
              value={City}
              onChange={e => onInputChange(e)}
            />
                    

                    </div>
                    <div className="mb-3 col-lg-6 col-md-6 col-12">
                        <label htmlFor="State" className="form-label">STATE</label>
                        
                        <input
              type="text"
              className="form-control form-control-sm"
              placeholder="STATE"
              name="State"
              value={State}
              onChange={e => onInputChange(e)}
            />

                    </div>
                    <div className="mb-3 col-lg-6 col-md-6 col-12">
                        <label htmlFor="exampleInputtext" className="form-label">COUNTRY</label>
                       
                        <input
              type="text"
              className="form-control form-control-sm"
              placeholder="COUNTRY"
              name="Country"
              value={Country}
              onChange={e => onInputChange(e)}
            />

                    </div>
                    <div className="mb-3 col-lg-6 col-md-6 col-12">
                        <label htmlFor="Pincode" className="form-label">PINCODE</label>
                        
                        <input
              type="text"
              className="form-control form-control-sm"
              placeholder="PINCODE"
              name="Pincode"
              value={Pincode}
              onChange={e => onInputChange(e)}
            />

                    </div>
                    <div className="mb-3 col-lg-6 col-md-6 col-12">
                        <label htmlFor="STATUS" className="form-label">STATUS</label>
                        
                        <input
              type="text"
              className="form-control form-control-sm"
              placeholder="STATUS"
              name="Status"
              value={Status}
              onChange={e => onInputChange(e)}
            />
</div>
                    </div>
                    </div>
                    <div className="col-md-12 bg-light">
                    <button type="submit"  className="btn btn-primary submit-button">Add Distributor</button>
                    </div>
                    
            </form>
            </div>
            </div>

    </div>
    </div>

  )

  }

export default AddDistributors
