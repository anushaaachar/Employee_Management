import React, {useState,useEffect} from 'react';
import '../App.css'
import  {NavLink, useNavigate}  from 'react-router-dom';
import Navbar from './Navbar';
import Sidebar from './Sidebar';
import RemoveRedEyeIcon from '@mui/icons-material/RemoveRedEye';
import CreateIcon from '@mui/icons-material/Create';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';


export const Home = () => {
  const [empdata, empdatachange] = useState(null);
    const navigate = useNavigate();

    const LoadDetail = (id) => {
        navigate("/employee/detail/" + id);
    }
    const LoadEdit = (id) => {
        navigate("/employee/edit/" + id);
    }
    const Removefunction = (id) => {
        if (window.confirm('Do you want to remove?')) {
            fetch("http://localhost:3003/users/" + id, {
                method: "DELETE"
            }).then((res) => {
                alert('Removed successfully.')
                window.location.reload();
            }).catch((err) => {
                console.log(err.message)
            })
        }
    }

const Loadcolor=(Status)=>{
  console.log(Status);
  if(Status === "inactive"){
    return "RED"
  }else if(Status === "active"){
    return "GREEN"
  }

}


    useEffect(() => {
        fetch("http://localhost:3003/users").then((res) => {
            return res.json();
        }).then((resp) => {
            empdatachange(resp);
        }).catch((err) => {
            console.log(err.message);
        })
    }, [])
  

  return (
    <div className='row bg-light'>
        <div className='col-md-3'>
       <Sidebar/>
        </div>
        <div className='col-md-9'>
            <div className='bg-white'>
            <Navbar/>
            </div>
    <div className='mt-2'>
        Manage Distributors
    <div class="card">
      <div class="card-body">

        <div className='row'>
            <div className='col-md-1'>
            <button className='btn btn-primary status-button'>status</button>
            </div>
            <div className='col-md-10'>
                <div className='row'>
                    <div className='col-md-7'>

                    </div>
        
        {/* <Link to="/AddDistributors">
        <button className='btn btn-primary'>+</button>

      </Link> */}
   <div className='col-md-4'>
   <div class="form-group row text-right">
    <label for="staticEmail" className="col-sm-6 col-form-label search-label float-right">Search</label>
    <div class="col-sm-6">
      <input type="search"  placeholder="Search" className="form-control" id="staticEmail"></input>

      
    </div>
   
    </div>
    </div>
    <div className='col-md-1'>
    <div className='add_btn rounded-circle float-right'>
            <NavLink to="/AddDistributors/create" className='btn btn-primary'>+</NavLink>
        </div>
        </div>
        </div>
        </div>
        </div>

        <table className="table">
                        <thead>
                            <tr className="table-white">
                                <th scope="col">#</th>
                                <th scope="col">DISTRIBUTOR NAME</th>
                                <th scope="col">CONTACT PERSON</th>
                                <th scope="col">CONTACT NUMBER</th>
                                <th scope="col">CITY</th>
                                <th scope="col">STATE</th>
                                <th scope="col">COUNTRY</th>
                                <th scope="col">STATUS</th>
                                <th scope="col">ACTIONS</th>
                            </tr>
                        </thead>
                        <tbody>

{empdata &&
    empdata.map((item,id) => (
        <tr>
            <td>{id+1}</td>
            <td>{item.DistributorName}</td>
            <td>{item.ContactPerson}</td>
            <td>{item.ContactNumber}</td>
            <td>{item.City}</td>
            <td>{item.State}</td>
            <td>{item.Country}</td>
            <td className={item.Status === "active" ? "text-success  " : "text-danger"}>{item.Status}</td>
            <td>
            <button className="btn text-dark bg-transparent" onClick={() => LoadDetail(item.id)}><RemoveRedEyeIcon /></button>
            <button className="btn text-dark bg-transparent" onClick={() => LoadEdit(item.id)}><CreateIcon /></button>
            <button className="btn text-dark bg-transparent" onClick={() => Removefunction(item.id)}><DeleteOutlineIcon /></button>
            </td>
        </tr>
    ))
}

</tbody>
                    </table>
                    {/* pagination */}
                        
                    <nav aria-label="Page navigation example">
  <ul class="pagination bg-light text-secondary justify-content-end pagination-sm rounded">
  <li class="page-item">
  <div class="form-group c-select  no-margin">
                      <select name="" id="" class="form-control-sm text-secondary">
                          <option value="">10</option>
                        <option value="">9</option>
                        <option value="">8</option>
                        <option value="">7</option>
                        <option value="">6</option>
                        <option value="">5</option>
                        <option value="">4</option>
                      </select>
                  </div>
                  </li>
    <li class="page-item">
      <a class="page-link" href="#" aria-label="Previous">
        <span aria-hidden="true">&laquo;</span>
        <span class="sr-only">Previous</span>
      </a>
    </li>
    <li class="page-item">
      <a class="page-link" href="#" aria-label="Next">
        <span aria-hidden="true">&lsaquo;</span>
        <span class="sr-only">Next</span>
      </a>
    </li>
    <li class="page-item"><a class="page-link" href="#">1</a></li>
    <li class="page-item"><a class="page-link" href="#">2</a></li>
    <li class="page-item"><a class="page-link active" href="#">3</a></li>
    <li class="page-item"><a class="page-link" href="#">4</a></li>
    <li class="page-item"><a class="page-link" href="#">5</a></li>
    <li class="page-item">
      <a class="page-link" href="#" aria-label="Next">
        <span aria-hidden="true">&rsaquo;</span>
        <span class="sr-only">Next</span>
      </a>
    </li>
    <li class="page-item">
      <a class="page-link" href="#" aria-label="Next">
        <span aria-hidden="true">&raquo;</span>
        <span class="sr-only">Next</span>
      </a>
    </li>
  </ul>
</nav>
    </div>
    </div>
    </div>
    </div>
    </div>
  )
}

export default Home
